@echo off
chcp 65001 >nul
title ICD Code Query - Offline (English)

echo ============================================
echo   ICD Code Query  Offline v8.0 (EN)
echo ============================================
echo.
echo  Method 1: Double-click index_en.html directly (recommended)
echo  Method 2: Start local server using this script
echo.
echo  Starting...
echo.

cd /d "%~dp0"

:: Try to open in default browser
echo  Opening browser...
start "" "index_en.html"

:: Also start local server as backup
timeout /t 3 /nobreak >nul
echo.
echo  If data does not load properly in the browser, use:
echo  http://localhost:8300/index_en.html
echo.
echo  Press any key to start backup server (or close this window)
pause >nul

python -m http.server 8300 --bind 127.0.0.1
