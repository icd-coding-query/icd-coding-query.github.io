@echo off
chcp 65001 >nul
title ICD编码查询 - 离线版

echo ============================================
echo   ICD编码查询 离线版 v8.0
echo ============================================
echo.
echo  方式1：直接双击 index.html 即可使用（推荐）
echo  方式2：本脚本启动本地服务后使用
echo.
echo  正在启动...
echo.

cd /d "%~dp0"

:: 尝试用默认浏览器直接打开
echo  正在打开浏览器...
start "" "index.html"

:: 同时启动本地服务作为备选
timeout /t 3 /nobreak >nul
echo.
echo  如果浏览器中数据未正常加载，请使用以下地址：
echo  http://localhost:8300/index.html
echo.
echo  按任意键启动备选服务（或直接关闭此窗口）
pause >nul

python -m http.server 8300 --bind 127.0.0.1
