ICD Coding Query, Offline Edition — version 8.4
================================================

HOW TO RUN
----------
1. Unzip this whole folder to any local disk or USB stick.
2. Double-click  ICD编码查询-离线版/启动工具.bat
   (or open  ICD编码查询-离线版/index.html  in Chrome 60+ / Edge 79+).
3. A Chinese interface opens. An English interface is included:
   start it with  启动工具_英文版.bat  (or open index_en.html directly).

DATA
----
12 data modules, 282,015 entries (about 60 MB), all loaded locally.
Nothing leaves the machine; the tool runs with the network disconnected.
No installation, no administrator privileges, no network connection required.

WHAT TO TRY
-----------
- ICD-10 tab: type  伤寒  (typhoid) for an exact hit.
- Disorder tolerance: type  鼻手术主动脉弓人工血管置换  - a reordered phrase that is
  NOT a contiguous substring; exactly one candidate is returned: 38.4504.
- Partial-coverage fallback (new in 8.4): type  酒精性反流性食管炎 . No entry contains
  this exact phrase, so the exact tiers return nothing; the fallback tier then lists up
  to 10 fuzzy candidates, headed by  K21.001 反流性食管炎 .
- Dual-version crosswalk: disease entries show the national clinical version 2.0 and the
  medical insurance version 2.0 codes side by side; mismatches are flagged automatically.

LICENSE
-------
Creative Commons Attribution-NonCommercial 4.0 International (CC BY-NC 4.0).
See LICENSE.txt. The software is provided "as is", without warranty of any kind.
Retrieval results are for reference only; the final coding decision must be made by a
qualified coder according to the coding rules in force.
